<?php
/* DokuWiki Progressbar plugin
 * Internal version 1.1.0
 * 
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Alessandro Celli <aelsantex@gmail.com>
 * Copyright (C) 2009 Mischa The Evil
 * Copyright (C) 2006 Mike Smith
 */


if(!defined('DOKU_INC')) define('DOKU_INC',realpath(dirname(__FILE__).'/../../').'/');
if(!defined('DOKU_PLUGIN')) define('DOKU_PLUGIN',DOKU_INC.'lib/plugins/');
require_once(DOKU_PLUGIN.'syntax.php');

class syntax_plugin_progressbar extends DokuWiki_Syntax_Plugin
{
 
	/** What kind of syntax are we? */
	function getType() {	return 'substition';	}
	function getAllowedTypes() { return array('formatting', 'substition', 'disabled'); }   
    
	/** Where to sort in? */ 
	function getSort(){ return 799; }

	function connectTo($mode)
	{
		$this->Lexer->addSpecialPattern('<progress=(?:10|[1-9]?)0>', $mode, 'plugin_progressbar');
	}
 
	/**
	 * Handle the match
	 */
	public function handle($match, $state, $pos, Doku_Handler $handler){
		substr($match, 10, -1);
		return array(substr($match, 10, -1));
	}
 
	/**
	 * Create output
	 */
        public function render($mode, Doku_Renderer $renderer, $data) {                                                                                                                                                                                                                   if($mode !== 'xhtml' && $mode !== 'odt' && $mode !== 'odt_pdf') {                                                                                                                                                                                                                 return false;                                                                                                                                                                                                                                                             }
		$renderer->doc .= '<img width="100" height="16" src="'. DOKU_URL .'lib/plugins/progressbar/images/' . $data[0] . '.gif" alt="' . $data[0] . '% completed" title="' . $data[0] . '% completed" />';
		return true;
	}

	//function postConnect() { $this->Lexer->addExitPattern('</color>','plugin_color'); }
 
	/** return some info */
	function getInfo() {
		return array
		(
			'author' => 'Alessandro Celli',
			'email'  => 'aelsantex@gmail.com',
			'date'   => '2025-03-06',
			'name'   => 'Progressbar',
			'desc'   => 'Makes progress bars on wiki pages.',
			'url'    => 'https://www.dokuwiki.org/plugin:progressbar',
		);
	}
 

    /**
     * Handle the match
     */
    /*function handle($match, $state, $pos, Doku_Handler $handler) {
        switch ($state) {
          case DOKU_LEXER_ENTER :		return array(substr($match, 10, -1));
          case DOKU_LEXER_UNMATCHED :	return array($state, $match);
          case DOKU_LEXER_EXIT :		return array($state, '');
        }
        return array();
    }*/
 
    /**
     * Create output
     */
    /*function render($mode, Doku_Renderer $renderer, $data) {
        if($mode == 'xhtml'){
            list($state, $match) = $data;
            switch ($state) {
              case DOKU_LEXER_ENTER :      
                $renderer->doc .= '<img width="100" height="16" src="'. DOKU_URL .'lib/plugins/progressbar/images/' . $data[0] . '.gif" alt="' . $data[0] . '% completed" title="' . $data[0] . '% completed" />';
				break;
              case DOKU_LEXER_UNMATCHED :  $renderer->doc .= " "; break;
              case DOKU_LEXER_EXIT :       $renderer->doc .= " "; break;
            }
            return true;
        }
        return false;
    }*/

}


